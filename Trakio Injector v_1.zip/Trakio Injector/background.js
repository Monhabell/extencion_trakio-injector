console.log("El archivo background.js está funcionando.");
